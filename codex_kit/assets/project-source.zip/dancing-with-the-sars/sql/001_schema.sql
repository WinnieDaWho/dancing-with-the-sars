BEGIN;

CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS nisar_products (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_id text NOT NULL UNIQUE,
    product_type text NOT NULL CHECK (product_type IN ('GCOV', 'GUNW')),
    acquisition_start timestamptz,
    acquisition_end timestamptz,
    source_url text,
    footprint geometry(MultiPolygon, 4326) NOT NULL,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (ST_IsValid(footprint)),
    CHECK (acquisition_end IS NULL OR acquisition_start IS NULL OR acquisition_end >= acquisition_start)
);

CREATE INDEX IF NOT EXISTS nisar_products_footprint_gix
    ON nisar_products USING gist (footprint);

CREATE INDEX IF NOT EXISTS nisar_products_acquisition_start_idx
    ON nisar_products (acquisition_start);

COMMIT;
