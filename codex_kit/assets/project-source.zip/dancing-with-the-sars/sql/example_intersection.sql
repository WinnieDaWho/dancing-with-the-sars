-- Replace the coordinates with a WGS 84 area-of-interest polygon.
WITH area_of_interest AS (
    SELECT ST_GeomFromText(
        'POLYGON((-79.7 43.4, -79.1 43.4, -79.1 44.0, -79.7 44.0, -79.7 43.4))',
        4326
    ) AS geom
)
SELECT p.product_id, p.product_type, p.acquisition_start
FROM nisar_products AS p
CROSS JOIN area_of_interest AS aoi
WHERE ST_Intersects(p.footprint, aoi.geom)
ORDER BY p.acquisition_start DESC NULLS LAST;
