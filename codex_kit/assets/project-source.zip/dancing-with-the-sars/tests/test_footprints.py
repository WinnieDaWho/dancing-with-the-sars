import pytest

from nisar_space_apps.footprints import bounds_to_wgs84_geojson


def test_regular_bounds_become_one_multipolygon_part() -> None:
    geometry = bounds_to_wgs84_geojson((-79.7, 43.4, -79.1, 44.0), "EPSG:4326")

    assert geometry["type"] == "MultiPolygon"
    assert len(geometry["coordinates"]) == 1


def test_antimeridian_bounds_split_into_two_parts() -> None:
    geometry = bounds_to_wgs84_geojson((170, -10, -170, 10), "EPSG:4326")

    assert geometry["type"] == "MultiPolygon"
    assert len(geometry["coordinates"]) == 2


@pytest.mark.parametrize(
    ("bounds", "message"),
    [
        ((0, 0, 1), "west, south, east, north"),
        ((0, 10, 1, 0), "south must be less"),
    ],
)
def test_invalid_bounds_are_rejected(bounds: tuple[float, ...], message: str) -> None:
    with pytest.raises(ValueError, match=message):
        bounds_to_wgs84_geojson(bounds, "EPSG:4326")
