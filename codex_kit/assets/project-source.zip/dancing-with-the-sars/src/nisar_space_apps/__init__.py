"""Open tools for working with NISAR product footprints."""

from .footprints import bounds_to_wgs84_geojson

__all__ = ["bounds_to_wgs84_geojson"]
