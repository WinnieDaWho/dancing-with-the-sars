"""Small, explicit PostGIS persistence helpers."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import Any

import psycopg


def upsert_product(
    connection: psycopg.Connection[Any],
    *,
    product_id: str,
    product_type: str,
    footprint_geojson: Mapping[str, object],
    acquisition_start: datetime | None = None,
    acquisition_end: datetime | None = None,
    source_url: str | None = None,
    metadata: Mapping[str, object] | None = None,
) -> None:
    """Insert or update public product metadata and its WGS 84 footprint."""

    if product_type not in {"GCOV", "GUNW"}:
        raise ValueError("product_type must be GCOV or GUNW")

    with connection.cursor() as cursor:
        cursor.execute(
            """
            INSERT INTO nisar_products (
                product_id, product_type, acquisition_start, acquisition_end,
                source_url, footprint, metadata
            )
            VALUES (
                %(product_id)s, %(product_type)s, %(acquisition_start)s,
                %(acquisition_end)s, %(source_url)s,
                ST_Multi(ST_SetSRID(ST_GeomFromGeoJSON(%(footprint)s), 4326)),
                %(metadata)s
            )
            ON CONFLICT (product_id) DO UPDATE SET
                product_type = EXCLUDED.product_type,
                acquisition_start = EXCLUDED.acquisition_start,
                acquisition_end = EXCLUDED.acquisition_end,
                source_url = EXCLUDED.source_url,
                footprint = EXCLUDED.footprint,
                metadata = EXCLUDED.metadata,
                updated_at = now()
            """,
            {
                "product_id": product_id,
                "product_type": product_type,
                "acquisition_start": acquisition_start,
                "acquisition_end": acquisition_end,
                "source_url": source_url,
                "footprint": json.dumps(footprint_geojson),
                "metadata": json.dumps(metadata or {}),
            },
        )
