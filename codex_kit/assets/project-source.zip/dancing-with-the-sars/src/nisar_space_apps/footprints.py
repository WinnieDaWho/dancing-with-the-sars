"""Convert raster bounds into PostGIS-ready WGS 84 footprints."""

from __future__ import annotations

from collections.abc import Sequence

from pyproj import CRS, Transformer
from shapely.geometry import MultiPolygon, box, mapping


def bounds_to_wgs84_geojson(
    bounds: Sequence[float],
    source_crs: str | CRS,
) -> dict[str, object]:
    """Return a GeoJSON MultiPolygon for raster bounds.

    ``bounds`` must contain ``west, south, east, north`` in ``source_crs``.
    Projected bounds are densified while transforming so their WGS 84 envelope
    is not calculated from only four corners. Antimeridian-crossing results are
    represented as two polygons.
    """

    if len(bounds) != 4:
        raise ValueError("bounds must contain west, south, east, north")

    west, south, east, north = (float(value) for value in bounds)
    if south >= north:
        raise ValueError("south must be less than north")

    crs = CRS.from_user_input(source_crs)
    if crs.is_geographic and west > east:
        transformed = (west, south, east, north)
    else:
        if west >= east:
            raise ValueError("west must be less than east for non-wrapping bounds")
        transformer = Transformer.from_crs(crs, "EPSG:4326", always_xy=True)
        transformed = transformer.transform_bounds(
            west,
            south,
            east,
            north,
            densify_pts=21,
        )

    wgs_west, wgs_south, wgs_east, wgs_north = transformed
    if wgs_east < wgs_west:
        polygons = [
            box(wgs_west, wgs_south, 180.0, wgs_north),
            box(-180.0, wgs_south, wgs_east, wgs_north),
        ]
    else:
        polygons = [box(wgs_west, wgs_south, wgs_east, wgs_north)]

    return mapping(MultiPolygon(polygons))
