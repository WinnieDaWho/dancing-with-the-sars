# Contributing

Thank you for helping. Keep contributions small, documented, and reproducible.

1. Open an issue describing the change and public data source.
2. Create a branch from `main`.
3. Run `ruff check .` and `pytest` locally.
4. Include tests for geometry or metadata behavior.
5. Confirm that no credentials, private code, local paths, or large data files
   appear in the diff.
6. Cite upstream code and preserve its license notices.

By contributing, you agree that your contribution is licensed under Apache-2.0.
