# Security policy

## Credential hygiene

Never commit Earthdata usernames, passwords, `.netrc` files, cookies, API
tokens, private keys, database dumps, or populated `.env` files. Use only fake
placeholders in examples. Large Earth-observation products must remain outside
Git and are ignored by default.

If a credential is committed, treat it as exposed even if the commit is later
deleted: revoke or rotate it immediately, then remove it from Git history.

## Reporting a vulnerability

Please use GitHub's private vulnerability reporting feature when it is enabled.
Do not open a public issue containing an active secret or exploitable detail.
