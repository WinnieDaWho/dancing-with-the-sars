# Earthdata authentication

NASA Earthdata credentials are personal secrets. Create an Earthdata Login in
your browser, then prefer the authentication mechanism supported by the current
`earthaccess` documentation. Never paste credentials into source code,
notebooks, issues, or GitHub Actions logs.

For tools that require `.netrc`, create it in your **home directory**, not this
repository, and restrict it to your user:

```text
machine urs.earthdata.nasa.gov
login YOUR_EARTHDATA_USERNAME
password YOUR_EARTHDATA_PASSWORD
```

```bash
chmod 600 ~/.netrc
```

The project `.gitignore` excludes `.netrc`, `_netrc`, `.env`, and common key
formats as defense in depth. Ignoring a file does not make an exposed credential
safe: revoke or rotate anything that reaches Git history.

Before implementing product discovery, verify the current instructions at:

- https://nisar-docs.asf.alaska.edu/using-open-source/
- https://github.com/ASFOpenSARlab/NISAR_Cookbook
- https://github.com/nasa/spaceapps/discussions/2068
