# Architecture

The initial data flow is intentionally narrow:

```text
Earthdata / ASF search
        |
        v
Public product metadata + remote HDF5 metadata
        |
        v
GCOV metadata adapter (to be verified against a real sample)
        |
        v
WGS 84 MultiPolygon + normalized product fields
        |
        v
PostgreSQL / PostGIS
        |
        v
ST_Intersects and other spatial queries
```

The discovery adapter, HDF5 adapter, geometry conversion, and persistence layer
remain separate so a metadata-path change cannot silently alter database
behavior. Raw pixels and bulk products are not stored in Git or PostGIS.

## Trust boundaries

- Credentials live in a user's credential store or user-level `.netrc`.
- The repository contains public code and fake configuration only.
- Remote metadata is untrusted input and must be validated.
- Product geometry is normalized to EPSG:4326 and checked by PostGIS.
- Proprietary systems are neither imported nor accessed by this project.
