# Initial data model

`nisar_products` stores one normalized record per public product.

| Column | Purpose |
|---|---|
| `product_id` | Stable provider product identifier |
| `product_type` | `GCOV` initially; `GUNW` reserved for the next phase |
| `acquisition_start`, `acquisition_end` | Observation time interval |
| `source_url` | Public metadata or asset URL; never an authenticated URL |
| `footprint` | Valid WGS 84 `MultiPolygon`, indexed with GiST |
| `metadata` | Additional public metadata not yet normalized |

The original product CRS should be retained in `metadata`. The footprint is
stored in EPSG:4326 to make area-of-interest queries consistent. Pixel arrays
and full HDF5 products do not belong in this table.
