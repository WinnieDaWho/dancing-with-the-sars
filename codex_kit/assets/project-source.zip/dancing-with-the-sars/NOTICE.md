# Notices and attribution

Copyright 2026 NISAR Space Apps contributors.

Project identity: Dancing with the SARs — Team RHD Labs.

The original static showcase, procedural comparison images, concept animation,
and procedural ambient music are original project materials. They are synthetic
illustrations and do not contain measured NISAR data.

The NISAR Cookbook is Apache-2.0. The gods-eye-view source code includes an MIT
grant, but its third-party datasets and runtime feeds have separate terms.
Neither upstream repository's source or assets is bundled in this delivery.

This project refers to public documentation and examples from NASA, the Alaska
Satellite Facility (ASF), ISRO, and the open-source geospatial community.
Their names and marks remain the property of their respective owners and do not
imply endorsement.

No source code from the NISAR Cookbook has been copied into this repository at
initial creation. Before adapting an upstream example, record its source,
license, relevant file, and modifications here, and preserve any notices its
license requires.

Useful upstream references:

- NISAR Cookbook: https://github.com/ASFOpenSARlab/NISAR_Cookbook
- NISAR open-source software guidance: https://nisar-docs.asf.alaska.edu/using-open-source/
- NASA Space Apps NISAR discussion: https://github.com/nasa/spaceapps/discussions/2068
