# Dancing with the SARs — RHD Labs

A GCOV-first NISAR surface-change concept for the **2026 NASA International Space Apps Challenge**, by **RHD Labs**, Toronto, Canada. Original code is licensed under [Apache-2.0](LICENSE).

The project asks how radar observations can become an understandable, traceable view of a changing landscape. The showcase uses Saskatchewan agricultural-moisture and British Columbia slope-change scenarios to explain the idea.

## What is actually included

| Component | Status |
|---|---|
| Responsive public showcase / comparison slider / architecture walkthrough | Included in `showcase/` |
| Synthetic Canadian demonstration scenarios | Included; explicitly simulated |
| Captioned concept reel / seven-slide deck / submission copy | Included in the release kit |
| Python bounds-to-WGS84 helper, PostGIS persistence helper, initial schema | Included |
| Live Earthdata search, remote GCOV adapter, change detection | Separate application integration; not implemented here |
| gods-eye-view layer, GEV MIC tools, Director Mode | Assigned to Claude/Fable; not bundled here |
| Real radar detections, saturation retrievals, evacuation alerts | Not demonstrated by this package |

This is an independent community project. Mission and provider names identify sources, not endorsement.

## Architecture

```mermaid
flowchart LR
    A["NASA Earthdata / ASF\nNISAR GCOV; GUNW later"] --> B["Python window reader\nearthaccess + supported HDF5 transport"]
    B --> C["Matched observations\nquality masks + change analysis"]
    C --> D["PostgreSQL / PostGIS\nprovenance + geometry + GiST"]
    D --> E["FastAPI / GeoJSON\nexplicit live or simulated mode"]
    E --> F["gods-eye-view / CesiumJS\nmap, timeline, voice integration"]
    G["Static public showcase\nsynthetic examples"] -. explains .-> F
```

This diagram is the integration target, not a claim that every service is deployed. The static showcase runs independently and does not call a production API.

## Run the included foundation

Requirements: Python 3.11+, Docker with Compose, and Git.

```bash
# After the intended public repository has been created and this package pushed:
git clone https://github.com/WinnieDaWho/dancing-with-the-sars.git
cd dancing-with-the-sars
cp .env.example .env
# Edit .env and choose a strong local database password before continuing.
docker compose up -d
docker compose exec -T postgis sh -c 'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' < sql/001_schema.sql
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
ruff check .
pytest
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1`. The optional `data` extra installs `earthaccess`, `asf-search`, and `h5py` for future adapter work; it does not implement an ingestion workflow. The database port binds to loopback only.

For the portable showcase, serve `showcase/` with any static host. Its only dependencies are its adjacent assets. Set the public `SHOWCASE_CONFIG.githubUrl` and `liveDemoUrl` in `showcase/index.html` after those destinations are verified.

## Scientific scope and provenance

All comparison images and scenario values in the showcase are synthetic. No NISAR granule has been analyzed by this package. Backscatter change alone is not a saturation percentage or water-depth measurement. GUNW displacement is relative along the radar line of sight and requires processing and validation before interpretation. The scenarios do not constitute hazard forecasts or evacuation recommendations.

Real results must preserve granule identifiers, observation dates, source URLs, product/mode/polarization, CRS, algorithm, masks, and uncertainty. A seeded fallback must identify itself as simulated in API responses and spoken briefings.

## Public data and upstream credits

- **NASA / ISRO NISAR** — mission and scientific background: https://nisar.jpl.nasa.gov/
- **NASA Earthdata / Alaska Satellite Facility DAAC** — access and NISAR product documentation: https://nisar-docs.asf.alaska.edu/
- **ASF OpenSARLab / NISAR_Cookbook** — Apache-2.0 reference workflows: https://github.com/ASFOpenSARlab/NISAR_Cookbook
- **Bilawal Sidhu / gods-eye-view** — target globe integration; MIT source-code license, with separate terms for third-party datasets: https://github.com/bilawalsidhu/gods-eye-view
- **PostGIS**, **pyproj**, **Shapely**, **earthaccess**, **h5py**, and **asf_search** — separately licensed dependencies/references. No upstream globe code, notebooks, or third-party datasets are bundled here.

## Repository boundaries

The project is independent of proprietary SIARS/LinkBucket implementations. No municipal permits, real-estate data, private schemas, credentials, or internal configuration are included. `.env`, `.netrc`, raw HDF5/raster files, and local overrides are ignored. Keep Earthdata credentials in a user-level credential store; see [authentication setup](docs/earthdata-setup.md).

## Handoff and disclosure

Read [the handoff](docs/HANDOFF.md), [submission copy](docs/submission-copy.md), [data/API contract](docs/integration-contract.json), and [AI/data disclosure](docs/ai-and-data-disclosure.md). Gemini supplied the outline; Codex assisted with the included showcase and packaging. Claude/Fable's separate application contributions should be documented after integration. Media-generation attempts that failed are not credited as completed assets.

See [NOTICE.md](NOTICE.md), [CONTRIBUTING.md](CONTRIBUTING.md), and [SECURITY.md](SECURITY.md).
